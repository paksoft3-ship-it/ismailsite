# Component Placement Guide
# Hasarlı Araç Alım Merkezi - New Components

## File Paths
All components are in: `src/components/sections/`

---

## 1. NewsMarquee
**Path:** `src/components/sections/NewsMarquee.tsx`
**Add to:** `src/app/layout.tsx` - At the very top, ABOVE the Header
```tsx
import NewsMarquee from '@/components/sections/NewsMarquee';
// Inside body, before Header:
<NewsMarquee />
```

---

## 2. StatsCounter
**Path:** `src/components/sections/StatsCounter.tsx`
**Add to:** `src/app/page.tsx` - After Hero section
```tsx
import StatsCounter from '@/components/sections/StatsCounter';
// After <Hero />:
<StatsCounter />
```

---

## 3. QuickContactForm
**Path:** `src/components/sections/QuickContactForm.tsx`
**Add to:** `src/app/page.tsx` - After StatsCounter or Hero
```tsx
import QuickContactForm from '@/components/sections/QuickContactForm';
// After <StatsCounter />:
<QuickContactForm />
```

---

## 4. BrandLogos
**Path:** `src/components/sections/BrandLogos.tsx`
**Add to:** `src/app/page.tsx` - After Features section
```tsx
import BrandLogos from '@/components/sections/BrandLogos';
// After <Features />:
<BrandLogos />
```

---

## 5. Guarantees
**Path:** `src/components/sections/Guarantees.tsx`
**Add to:** `src/app/page.tsx` - After VehicleTypes or HowItWorks
**Also:** `src/app/hakkimizda/page.tsx`
```tsx
import Guarantees from '@/components/sections/Guarantees';
```

---

## 6. ProcessTimeline
**Path:** `src/components/sections/ProcessTimeline.tsx`
**Add to:** `src/app/page.tsx` - Replace or complement HowItWorks
**Also:** `src/app/hakkimizda/page.tsx`
```tsx
import ProcessTimeline from '@/components/sections/ProcessTimeline';
```

---

## 7. Testimonials
**Path:** `src/components/sections/Testimonials.tsx`
**Add to:** `src/app/page.tsx` - After Guarantees section
```tsx
import Testimonials from '@/components/sections/Testimonials';
// Usage:
<Testimonials limit={6} />
```

---

## 8. ServiceAreas
**Path:** `src/components/sections/ServiceAreas.tsx`
**Add to:** `src/app/page.tsx` - After Testimonials
**Also:** `src/app/hakkimizda/page.tsx`
```tsx
import ServiceAreas from '@/components/sections/ServiceAreas';
```

---

## 9. BlogPreview
**Path:** `src/components/sections/BlogPreview.tsx`
**Add to:** `src/app/page.tsx` - Before CTA section
```tsx
import BlogPreview from '@/components/sections/BlogPreview';
// Usage:
<BlogPreview limit={3} />
```

---

## 10. TrustBadges
**Path:** `src/components/sections/TrustBadges.tsx`
**Add to:** `src/app/page.tsx` - Just before Footer (after CTA)
```tsx
import TrustBadges from '@/components/sections/TrustBadges';
```

---

## 11. CallbackRequest
**Path:** `src/components/sections/CallbackRequest.tsx`
**Add to:** `src/app/layout.tsx` - Inside body, at the end (popup modal)
```tsx
import CallbackRequest from '@/components/sections/CallbackRequest';
// At the end of body, before closing tag:
<CallbackRequest />
```

---

## Recommended Homepage Order (src/app/page.tsx)

```tsx
import Hero from '@/components/sections/Hero';
import StatsCounter from '@/components/sections/StatsCounter';
import QuickContactForm from '@/components/sections/QuickContactForm';
import Features from '@/components/sections/Features';
import BrandLogos from '@/components/sections/BrandLogos';
import VehicleTypes from '@/components/sections/VehicleTypes';
import Guarantees from '@/components/sections/Guarantees';
import ProcessTimeline from '@/components/sections/ProcessTimeline';
import Testimonials from '@/components/sections/Testimonials';
import CitySelector from '@/components/sections/CitySelector';
import ServiceAreas from '@/components/sections/ServiceAreas';
import FAQ from '@/components/sections/FAQ';
import BlogPreview from '@/components/sections/BlogPreview';
import CTA from '@/components/sections/CTA';
import TrustBadges from '@/components/sections/TrustBadges';

export default function Home() {
  return (
    <>
      <Hero />
      <StatsCounter />
      <QuickContactForm />
      <Features />
      <BrandLogos />
      <VehicleTypes />
      <Guarantees />
      <ProcessTimeline />
      <Testimonials limit={6} />
      <CitySelector limit={12} />
      <ServiceAreas />
      <FAQ limit={6} />
      <BlogPreview limit={3} />
      <CTA />
      <TrustBadges />
    </>
  );
}
```

---

## Layout.tsx Updates

```tsx
// Add these imports:
import NewsMarquee from '@/components/sections/NewsMarquee';
import CallbackRequest from '@/components/sections/CallbackRequest';

// Update body:
<body>
  <NewsMarquee />
  {/* existing header and content */}
  <Header />
  <main>{children}</main>
  <Footer />
  <FloatingButtons />
  <CallbackRequest />
</body>
```

---

## Data Files Created
- `src/data/testimonials.json` - Customer reviews
- `src/data/blog.json` - Blog posts
- `src/data/guarantees.json` - Guarantees, stats, brands, partners
