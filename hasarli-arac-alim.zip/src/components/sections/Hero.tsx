'use client';

import siteData from '@/data/site.json';
import { FaWhatsapp, FaPhone, FaShieldAlt, FaClock, FaTruck } from 'react-icons/fa';

interface HeroProps {
  title?: string;
  subtitle?: string;
  showBadge?: boolean;
}

export default function Hero({ 
  title = 'Hasarlı Aracınızı En Yüksek Fiyata Satın!',
  subtitle = 'Kazalı, hasarlı, hurda veya pert aracınız için anında fiyat teklifi alın. 7/24 hizmet, aynı gün nakit ödeme garantisi.',
  showBadge = true 
}: HeroProps) {
  const handleWhatsAppClick = () => {
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'conversion', {
        send_to: `${siteData.googleAds.conversionId}/${siteData.googleAds.whatsappConversionLabel}`,
      });
    }
    window.open(
      `https://wa.me/${siteData.whatsapp}?text=${encodeURIComponent(
        'Merhaba, hasarlı aracım için fiyat teklifi almak istiyorum.'
      )}`,
      '_blank'
    );
  };

  const handlePhoneClick = () => {
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'conversion', {
        send_to: `${siteData.googleAds.conversionId}/${siteData.googleAds.phoneConversionLabel}`,
      });
    }
    window.location.href = `tel:${siteData.phone.replace(/\s/g, '')}`;
  };

  return (
    <section className="relative bg-gradient-to-br from-secondary via-gray-900 to-secondary overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2318b9b1' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-secondary/90 to-transparent" />

      <div className="container-custom relative z-10 py-16 md:py-24 lg:py-32">
        <div className="max-w-3xl">
          {/* Badge */}
          {showBadge && (
            <div className="inline-flex items-center gap-2 bg-primary/20 border border-primary/30 rounded-full px-4 py-2 mb-6 animate-fade-in-up">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span className="text-primary text-sm font-medium">Türkiye Geneli Hizmet</span>
            </div>
          )}

          {/* Title */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-6 leading-tight animate-fade-in-up">
            {title.split(' ').map((word, i) => (
              <span key={i}>
                {word.toLowerCase() === 'en' || word.toLowerCase() === 'yüksek' ? (
                  <span className="text-primary">{word} </span>
                ) : (
                  `${word} `
                )}
              </span>
            ))}
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-gray-300 mb-8 leading-relaxed animate-fade-in-up">
            {subtitle}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-12 animate-fade-in-up">
            <button
              onClick={handlePhoneClick}
              className="btn-primary text-lg px-8 py-4 group"
            >
              <FaPhone className="group-hover:animate-bounce" />
              HEMEN FİYAT AL
            </button>
            <button
              onClick={handleWhatsAppClick}
              className="btn-whatsapp text-lg px-8 py-4 group"
            >
              <FaWhatsapp className="text-2xl group-hover:scale-110 transition-transform" />
              WhatsApp ile Yaz
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-fade-in-up">
            <div className="flex items-center gap-3 text-white/80">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                <FaShieldAlt className="text-primary text-xl" />
              </div>
              <div>
                <p className="font-semibold text-white">Güvenli İşlem</p>
                <p className="text-sm text-gray-400">Noter Onaylı</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-white/80">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                <FaClock className="text-primary text-xl" />
              </div>
              <div>
                <p className="font-semibold text-white">Hızlı Ödeme</p>
                <p className="text-sm text-gray-400">Aynı Gün Nakit</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-white/80">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                <FaTruck className="text-primary text-xl" />
              </div>
              <div>
                <p className="font-semibold text-white">Yerinden Alım</p>
                <p className="text-sm text-gray-400">Ücretsiz Çekici</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute right-0 bottom-0 w-1/3 h-full hidden lg:block">
        <div className="absolute right-10 bottom-10 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute right-32 top-20 w-32 h-32 bg-primary/20 rounded-full blur-2xl" />
      </div>
    </section>
  );
}
